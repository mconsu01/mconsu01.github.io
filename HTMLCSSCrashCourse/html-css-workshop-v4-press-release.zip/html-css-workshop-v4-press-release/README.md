# HTML CSS Crash Course

## Let's get started!

This repository contains the code along for the press release.

Open the press_release_start.html to code your own press release

Look at press_release_example.html if you want some inspiration

Good luck!
